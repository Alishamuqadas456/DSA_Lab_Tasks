#include <iostream>
using namespace std;

struct Node {
    string title;
    float price;
    int edition;
    int pages;
    Node* next;
};

Node* top = nullptr;  


void push(string t, float p, int e, int pg) {
    Node* newNode = new Node();
    newNode->title = t;
    newNode->price = p;
    newNode->edition = e;
    newNode->pages = pg;
    newNode->next = top;
    top = newNode;
    cout << "Book " << t << " pushed." << endl;
}


void pop() {
    if (top == nullptr) {
        cout << "Stack is empty." << endl;
        return;
    }
    cout << "Book " << top->title << " popped." << endl;
    Node* temp = top;
    top = top->next;
    delete temp;
}


void peek() {
    if (top == nullptr) {
        cout << "Stack is empty.\n";
        return;
    }
    cout << "\nTop Book:\n";
    cout << "Title: " << top->title << endl;
    cout << "Price: " << top->price << endl;
    cout << "Edition: " << top->edition << endl;
    cout << "Pages: " << top->pages << endl;
}


void display() {
    if (top == nullptr) {
        cout << "Stack is empty." << endl;
        return;
    }
    cout << "\nBooks in stack:\n";
    Node* temp = top;
    while (temp != nullptr) {
        cout << "Title: " << temp->title
             << ", Price: " << temp->price
             << ", Edition: " << temp->edition
             << ", Pages: " << temp->pages << endl;
        temp = temp->next;
    }
}

int main() {
    
    push("C++ Basics", 550, 1, 300);
    push("Data Structures", 750, 2, 400);
    push("Algorithms", 850, 3, 500);
    push("OOP Concepts", 600, 1, 350);
    push("Computer Networks", 900, 2, 450);


    peek();


    pop();
    pop();

    display();

    return 0;
}
