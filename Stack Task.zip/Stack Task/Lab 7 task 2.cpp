#include <iostream>
using namespace std;

// ----------------- Inventory Class -----------------
class Inventory {
private:
    int serialNum;
    int manufactYear;
    int lotNum;

public:
    // Set data into inventory
    void setData(int s, int y, int l) {
        serialNum = s;
        manufactYear = y;
        lotNum = l;
    }

    // Display inventory data
    void displayData() {
        cout << "Serial Number: " << serialNum << endl;
        cout << "Manufacture Year: " << manufactYear << endl;
        cout << "Lot Number: " << lotNum << endl;
    }
};

// ----------------- Node for Stack (Linked List) -----------------
struct Node {
    Inventory part;
    Node* next;
};

// ----------------- Stack Class -----------------
class Stack {
private:
    Node* top;

public:
    Stack() {
        top = nullptr;
    }

    // Push inventory onto stack
    void push(Inventory p, bool showMessage = true) {
        Node* newNode = new Node;
        newNode->part = p;
        newNode->next = top;
        top = newNode;
        if (showMessage) {
            cout << "Part added successfully!\n\n";
        }
    }

    // Pop inventory from stack
    void pop() {
        if (top == nullptr) {
            cout << "Inventory is empty. Nothing to take.\n\n";
            return;
        }
        cout << "Part removed:\n";
        top->part.displayData();
        Node* temp = top;
        top = top->next;
        delete temp;
        cout << endl;
    }

    // Display all remaining inventory
    void displayAll() {
        if (top == nullptr) {
            cout << "Inventory is empty.\n";
            return;
        }

        cout << "Remaining parts in inventory:\n";
        Node* temp = top;
        while (temp != nullptr) {
            temp->part.displayData();
            cout << "------------------\n";
            temp = temp->next;
        }
    }
};

// ----------------- Main Program -----------------
int main() {
    Stack inventoryStack;

    // ---------------- Preload some inventory data ----------------
    Inventory part1, part2, part3;
    part1.setData(101, 2021, 5001);
    part2.setData(102, 2022, 5002);
    part3.setData(103, 2023, 5003);

    inventoryStack.push(part1, false);
    inventoryStack.push(part2, false);
    inventoryStack.push(part3, false);

    // ---------------- Main Loop ----------------
    int choice;
    do {
        cout << "Inventory Menu:\n";
        cout << "1. Add Part\n";
        cout << "2. Take Part\n";
        cout << "0. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        if (choice == 1) {
            int s, y, l;
            cout << "Enter Serial Number: ";
            cin >> s;
            cout << "Enter Manufacture Year: ";
            cin >> y;
            cout << "Enter Lot Number: ";
            cin >> l;

            Inventory part;
            part.setData(s, y, l);
            inventoryStack.push(part);  

        } else if (choice == 2) {
            inventoryStack.pop();
        }

        cout << endl;

    } while (choice != 0);

    // Display all remaining parts
    inventoryStack.displayAll();

    return 0;
}
