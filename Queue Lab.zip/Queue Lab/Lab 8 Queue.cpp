#include <iostream>
#include <string>
using namespace std;

struct Applicant {
    int id;
    float height, weight, eyesight;
    string status;
    Applicant* next;
    Applicant* prev;
};
Applicant* frontPtr = NULL;
Applicant* rearPtr = NULL;
void enqueue(int id, float height, float weight, float eyesight, string status) {
    Applicant* newNode = new Applicant;
    newNode->id = id;
    newNode->height = height;
    newNode->weight = weight;
    newNode->eyesight = eyesight;
    newNode->status = status;
    newNode->next = NULL;
    newNode->prev = NULL;
    if (rearPtr == NULL) {
        frontPtr = rearPtr = newNode;
    } else {
        rearPtr->next = newNode;
        newNode->prev = rearPtr;
        rearPtr = newNode;
    }
}
void dequeue() {
    if (frontPtr == NULL) {
        cout << "\nQueue is empty!\n";
        return;
    }
    Applicant* temp = frontPtr;
    frontPtr = frontPtr->next;
    if (frontPtr != NULL)
        frontPtr->prev = NULL;
    else
        rearPtr = NULL;

    cout << "\nApplicant ID " << temp->id << " completed the test and left the line.\n";
    delete temp;
}
//remove player
void removeSecond() {
    if (frontPtr == NULL || frontPtr->next == NULL) {
        cout << "\nNot enough applicants to remove 2nd one.\n";
        return;
    }

    Applicant* temp = frontPtr->next;
    frontPtr->next = temp->next;
    if (temp->next != NULL)
        temp->next->prev = frontPtr;
    else
        rearPtr = frontPtr;

    cout << "\nApplicant ID " << temp->id << " had urgency and left the line.\n";
    delete temp;
}
void displayQueue() {
    if (frontPtr == NULL) {
        cout << "\nQueue is empty!\n";
        return;
    }

    cout << "\nCurrent Applicants in Queue:\n";
    cout << "------------------------------------------\n";

    Applicant* temp = frontPtr;
    while (temp != NULL) {
        cout << "Applicant Details:\n";
        cout << "  ID: " << temp->id << endl;
        cout << "  Height: " << temp->height << endl;
        cout << "  Weight: " << temp->weight << endl;
        cout << "  Eyesight: " << temp->eyesight << endl;
        cout << "  Status: " << temp->status << endl;
       
        temp = temp->next;
    }
}

int main() {
    enqueue(1, 5.8, 70, 1.0, "Pending");
    enqueue(2, 5.6, 68, 1.2, "Pending");
    enqueue(3, 5.9, 75, 0.9, "Pending");
    enqueue(4, 6.0, 80, 1.1, "Pending");
    enqueue(5, 5.5, 65, 1.3, "Pending");
    enqueue(6, 5.7, 72, 1.0, "Pending");
    enqueue(7, 5.8, 77, 1.1, "Pending");

    cout << "\nInitial Queue:\n";
    displayQueue();

    removeSecond();
    cout << "\nAfter removing 2nd applicant:\n";
    displayQueue();

    dequeue();
    cout << "\nAfter 1st applicant completed test:\n";
    displayQueue();

    enqueue(8, 6.1, 78, 1.0, "Pending");
    cout << "\nAfter adding new applicant at end:\n";
    displayQueue();

    return 0;
}
