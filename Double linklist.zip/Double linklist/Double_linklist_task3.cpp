#include <iostream>
#include <string>
using namespace std;

class Player {
public:
    string name;
    int score;
    Player* next;
    Player* pre;
};

// Function to add player in sorted order (ascending by score)
Player* addPlayer(Player* head, string name, int score) {
    Player* newPlayer = new Player();
    newPlayer->name = name;
    newPlayer->score = score;
    newPlayer->next = nullptr;
    newPlayer->pre = nullptr;

    if (head == nullptr) {
        return newPlayer; // first node
    }

    // Insert at beginning
    if (score < head->score) {
        newPlayer->next = head;
        head->pre = newPlayer;
        return newPlayer;
    }

    Player* temp = head;
    while (temp->next != nullptr && temp->next->score <= score) {
        temp = temp->next;
    }

    // Insert after temp
    newPlayer->next = temp->next;
    newPlayer->pre = temp;
    if (temp->next != nullptr) {
        temp->next->pre = newPlayer;
    }
    temp->next = newPlayer;

    return head;
}

// Delete player by name
Player* deletePlayer(Player* head, string name) {
    Player* temp = head;

    while (temp != nullptr && temp->name != name) {
        temp = temp->next;
    }

    if (temp == nullptr) {
        cout << "Player not found!" << endl;
        return head;
    }

    if (temp->pre != nullptr) {
        temp->pre->next = temp->next;
    } else {
        head = temp->next; // deleting head
    }

    if (temp->next != nullptr) {
        temp->next->pre = temp->pre;
    }

    delete temp;
    return head;
}

// Display whole list
void displayList(Player* head) {
    Player* temp = head;
    cout << "Players (Name - Score):" << endl;
    while (temp != nullptr) {
        cout << temp->name << " - " << temp->score << endl;
        temp = temp->next;
    }
}

// Display players with lowest score
void displayLowestScore(Player* head) {
    if (head == nullptr) return;
    int minScore = head->score;
    cout << "Player(s) with lowest score (" << minScore << "):" << endl;
    Player* temp = head;
    while (temp != nullptr && temp->score == minScore) {
        cout << temp->name << " - " << temp->score << endl;
        temp = temp->next;
    }
}

// Display players with same score
void displaySameScore(Player* head, int score) {
    Player* temp = head;
    cout << "Player(s) with score " << score << ":" << endl;
    bool found = false;
    while (temp != nullptr) {
        if (temp->score == score) {
            cout << temp->name << " - " << temp->score << endl;
            found = true;
        }
        temp = temp->next;
    }
    if (!found) cout << "No player found with score " << score << endl;
}

// Display backward from a player
void displayBackward(Player* head, string name) {
    Player* temp = head;
    while (temp != nullptr && temp->name != name) {
        temp = temp->next;
    }
    if (temp == nullptr) {
        cout << "Player not found!" << endl;
        return;
    }
    cout << "Backward from " << name << ":" << endl;
    while (temp != nullptr) {
        cout << temp->name << " - " << temp->score << endl;
        temp = temp->pre;
    }
}

int main() {
    Player* head = nullptr;
    int choice;

    do {
        cout << "\nGolf Tournament Menu:\n";
        cout << "1. Add Player\n";
        cout << "2. Delete Player\n";
        cout << "3. Display Whole List\n";
        cout << "4. Display Player(s) with Lowest Score\n";
        cout << "5. Display Players with Same Score\n";
        cout << "6. Display Backward from Player\n";
        cout << "0. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: {
                string name;
                int score;
                cout << "Enter player name: ";
                cin >> ws;
                getline(cin, name);
                cout << "Enter player score: ";
                cin >> score;
                head = addPlayer(head, name, score);
                break;
            }
            case 2: {
                string name;
                cout << "Enter name of player to delete: ";
                cin >> ws;
                getline(cin, name);
                head = deletePlayer(head, name);
                break;
            }
            case 3:
                displayList(head);
                break;
            case 4:
                displayLowestScore(head);
                break;
            case 5: {
                int score;
                cout << "Enter score to search: ";
                cin >> score;
                displaySameScore(head, score);
                break;
            }
            case 6: {
                string name;
                cout << "Enter name of player to display backward from: ";
                cin >> ws;
                getline(cin, name);
                displayBackward(head, name);
                break;
            }
            case 0:
                cout << "Exiting..." << endl;
                break;
            default:
                cout << "Invalid choice! Try again." << endl;
        }
    } while (choice != 0);

    return 0;
}
