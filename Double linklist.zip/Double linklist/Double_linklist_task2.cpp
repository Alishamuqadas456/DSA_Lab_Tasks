#include <iostream>
using namespace std;

// Node class for doubly linked list
class Node {
public:
    int rainfall;
    Node* next;
    Node* pre;
};

// Function to add node at the end
Node* addNode(Node* tail, int rainfall) {
    Node* newNode = new Node();
    newNode->rainfall = rainfall;
    newNode->next = nullptr;
    newNode->pre = tail;
    if (tail != nullptr) {
        tail->next = newNode;
    }
    return newNode;
}

// Function to display the list
void displayList(Node* head) {
    Node* temp = head;
    cout << "Rainfall for the week: ";
    int day = 1;
    while (temp != nullptr) {
        cout << "Day " << day << ": " << temp->rainfall << "  ";
        temp = temp->next;
        day++;
    }
    cout << endl;
}

int main() {
    Node* head = nullptr;
    Node* tail = nullptr;

    cout << "Enter rainfall for 7 days (non-negative numbers only):" << endl;
    for (int i = 1; i <= 7; i++) {
        int r;
        do {
            cout << "Day " << i << ": ";
            cin >> r;
            if (r < 0) {
                cout << "Rainfall cannot be negative! Enter again." << endl;
            }
        } while (r < 0);

        if (head == nullptr) {
            head = tail = addNode(nullptr, r);
        } else {
            tail = addNode(tail, r);
        }
    }

    displayList(head);

    // Calculate total and average rainfall
    int total = 0;
    int maxRainfall = -1;
    int minRainfall = 100000;
    int dayMax = 0, dayMin = 0;
    Node* temp = head;
    int day = 1;
    while (temp != nullptr) {
        total += temp->rainfall;
        if (temp->rainfall > maxRainfall) {
            maxRainfall = temp->rainfall;
            dayMax = day;
        }
        if (temp->rainfall < minRainfall) {
            minRainfall = temp->rainfall;
            dayMin = day;
        }
        temp = temp->next;
        day++;
    }

    double average = total / 7.0;

    cout << "\nTotal rainfall for the week: " << total << endl;
    cout << "Average weekly rainfall: " << average << endl;
    cout << "Day with highest rainfall: Day " << dayMax << " (" << maxRainfall << ")" << endl;
    cout << "Day with lowest rainfall: Day " << dayMin << " (" << minRainfall << ")" << endl;
    temp = head;
    day = 1;
    while (temp != nullptr && day <= 5) {
        temp = temp->next;
        day++;
    }
    if (temp != nullptr) {
        cout << "Rainfall of day after 5th node (Day 6): " << temp->rainfall << endl;
    } else {
        cout << "There is no day after 5th node." << endl;
    }

    return 0;
}
