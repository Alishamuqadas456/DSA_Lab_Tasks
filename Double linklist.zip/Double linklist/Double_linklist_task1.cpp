#include <iostream>
using namespace std;

// Node class for doubly linked list
class Node {
public:
    int data;
    Node* next;
    Node* pre;
};

// Function to create list with predefined values
Node* createList() {
    int values[] = {1, 45, 60, 12};
    int n = sizeof(values) / sizeof(values[0]);
    Node* head = nullptr;
    Node* tail = nullptr;

    for (int i = 0; i < n; i++) {
        Node* newNode = new Node();
        newNode->data = values[i];
        newNode->next = nullptr;
        newNode->pre = tail;

        if (head == nullptr) {
            head = newNode;
        } else {
            tail->next = newNode;
        }
        tail = newNode;
    }
    return head;
}

// Function to display the list
void displayList(Node* head) {
    Node* temp = head;
    cout << "Doubly linked list: ";
    while (temp != nullptr) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}

// Add node at beginning
Node* addAtBeginning(Node* head, int value) {
    Node* newNode = new Node();
    newNode->data = value;
    newNode->next = head;
    newNode->pre = nullptr;
    if (head != nullptr) {
        head->pre = newNode;
    }
    head = newNode;
    return head;
}

// Add node after node with value 45
void addAfterValue(Node* head, int value, int afterVal = 45) {
    Node* temp = head;
    while (temp != nullptr && temp->data != afterVal) {
        temp = temp->next;
    }
    if (temp != nullptr) { 
        Node* newNode = new Node();
        newNode->data = value;
        newNode->next = temp->next;
        newNode->pre = temp;
        if (temp->next != nullptr) {
            temp->next->pre = newNode;
        }
        temp->next = newNode;
    } else {
        cout << "Value " << afterVal << " not found in the list." << endl;
    }
}

// Delete node at beginning
Node* deleteAtBeginning(Node* head) {
    if (head == nullptr) return nullptr;
    Node* temp = head;
    head = head->next;
    if (head != nullptr) head->pre = nullptr;
    delete temp;
    return head;
}

// Delete node after node with value 45
void deleteAfterValue(Node* head, int afterVal = 45) {
    Node* temp = head;
    while (temp != nullptr && temp->data != afterVal) {
        temp = temp->next;
    }
    if (temp != nullptr && temp->next != nullptr) { 
        Node* toDelete = temp->next;
        temp->next = toDelete->next;
        if (toDelete->next != nullptr) {
            toDelete->next->pre = temp;
        }
        delete toDelete;
    } else {
        cout << "Cannot delete after value " << afterVal << "." << endl;
    }
}

int main() {
    Node* head = createList();
    displayList(head);

    cout << "\nAdding 100 at beginning." << endl;
    head = addAtBeginning(head, 100);
    displayList(head);

    cout << "\nAdding 77 after value 45." << endl;
    addAfterValue(head, 77);
    displayList(head);

    cout << "\nDeleting node at beginning." << endl;
    head = deleteAtBeginning(head);
    displayList(head);

    cout << "\nDeleting node after value 45." << endl;
    deleteAfterValue(head);
    displayList(head);

    return 0;
}
